<?php
    class DbConfig{

        private $_host = 'db_alunos.mysql.dbaas.com.br';
        private $_username = 'db_alunos';
        private $_password = 'Capile10##';
        private $_database = 'db_alunos';

        protected $connection;

        public function __construct(){

            if(!isset($this->connection)){

                $this->connection = new mysqli($this->_host, $this->_username, $this->_password, $this->_database);

                if(!$this->connection){
                    echo "Não foi possível conectar ao DB.";
                    exit;
                }

            }
            return $this->connection;
        }
    }
?>